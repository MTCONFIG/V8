config_aimbot = True
config_android_path = "com.activision.callofduty.shooter/files/"
config_status = "on"
