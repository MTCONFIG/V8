# DPI Configuration
dpi_config = {
    "DPI Version": "411    "Package Version": "com.activision.callofduty.shooter 1.0.45    "Android Version": "09 - 14}

# Sensibility Configuration
sensibility_config = {
    "Y Sensibility": "941999    "X Sensibility": "941555    "X Sensibility Reversed": "941999    "Y Sensibility Reversed": "999941    "System": True}

# Additional Settings by smoke
additional_settings = {
    "DPI": "411.00    "System": True    "Swipe YX": "0999987    "Swipe XY": "0999987    "System Setting": "0999987    "System Setting Enabled": True}